Sienna WAV conversion - laser cut files, 1 vehicle set (2026-11-02)
Units: INCHES. Sheet 48 x 96 in. Edge margin 0.5 in, gap between parts 0.3 in.
*_CUT.dxf    - cut geometry only (layer CUT). Give this file to the laser.
*_MARKED.dxf - same + layer SHEET (sheet outline), MARK (bend-line ticks at both ends, etch only - do not cut), LABEL (part names - do not cut).
*.pdf        - layout preview with part names and bend lines (blue dashed).
STEEL_11ga     : HR steel A1011 CS, 11 ga, t = 0.1196 in. FR + FL (mirror) frame parts, FF front parts, ST strut plates.
ALUMINUM_0.125 : Aluminum 5052-H32, t = 0.125 in. Ramp parts RA-1 ... RA-8.
Bend allowance is already in the flats (inside radius = t, K = 0.44).
Tubes are not on the sheets - cut list in tubes.csv.
For more vehicles repeat the sheets (1 sheet of each material per vehicle).
