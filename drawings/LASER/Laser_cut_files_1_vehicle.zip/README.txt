Sienna WAV conversion - laser cut files, 1 vehicle set (2026-11-02, rev 2)
Units: INCHES. Steel and aluminum: sheet 48 x 96 in. Stainless: one piece 12 x 24 in (offcut is fine). Edge margin 0.5 in, gap between parts 0.3 in.
*_CUT.dxf    - cut geometry only (layer CUT). Give this file to the laser.
*_MARKED.dxf - same + layer SHEET (sheet outline), MARK (bend-line ticks at both ends, etch only - do not cut), LABEL (part names - do not cut).
*.pdf        - layout preview with part names and bend lines (blue dashed).
STEEL_11ga     : HR steel A1011 CS, 11 ga, t = 0.1196 in. FR + FL (mirror) frame parts, FF front parts, ST strut plates.
ALUMINUM_0.125 : Aluminum 5052-H32, t = 0.125 in. Ramp parts RA-1, RA-2, RA-3A (plate with the "M&N / AUTO GROUP" stencil cut), RA-4 ... RA-8.
STAINLESS_18ga : Stainless 304 brushed #4, 18 ga, t = 0.048 in. RA-9 backing plate behind the RA-3A cut (brushed side faces the cut).
Bend allowance is already in the flats (inside radius = t, K = 0.44).
Tubes are not on the sheets - cut list in tubes.csv.
For more vehicles repeat the sheets (1 sheet of each material per vehicle).
